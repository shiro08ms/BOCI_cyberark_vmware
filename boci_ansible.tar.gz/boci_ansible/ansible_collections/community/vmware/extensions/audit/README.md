This directory, and the event_query.yml file, are used by AAP (RedHat) to capture metadata about certain module usage.
