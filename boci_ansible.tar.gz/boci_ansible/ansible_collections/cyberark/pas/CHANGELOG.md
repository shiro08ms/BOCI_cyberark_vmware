## 1.0.35

- Cleaned all tox issues (ruff, pylint, darglint)

## 1.0.34

- Fixed ruff and additional lint issues

## 1.0.33

- Fixed pylint issues

## 1.0.32

- Fixed tags in GitHub

## 1.0.31

- Changed in cyberark_authentication module to not reveal payload on failure

## 1.0.30

- Added ability to retrieve password

## 1.0.29

- Added documentation to update password only in Vault

## 1.0.27

- Fixed Pep8 & pylint for publication in Automation Hub

## 1.0.26

- Updated runtime.yml requirements to minimum 2.14.0
- Moved EDA collection to new/correct path
- Added CHANGELOG.md
