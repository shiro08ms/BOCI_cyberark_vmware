# Contributing to the Ansible Security Automation Collection

Thanks for your interest in the Ansible Security Automation collection.

For general community guidelines, please see the [community repo](https://github.com/cyberark/community).

## Pull Request Workflow

Currently, this repository is source-available and not open to contributions.  Please continue to follow this repository for updates and open-source availability
